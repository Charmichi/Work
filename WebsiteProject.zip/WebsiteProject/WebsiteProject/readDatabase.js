const sqlite3 = require('sqlite3').verbose();

// Open the database file
const db = new sqlite3.Database('database.db');

// Query to select all rows from the table
const query = 'SELECT * FROM inputs';

// Execute the query
db.all(query, [], (err, rows) => {
    if (err) {
        throw err;
    }

    // Output the rows to the console
    console.log(rows);
});

// Close the database connection
db.close();
