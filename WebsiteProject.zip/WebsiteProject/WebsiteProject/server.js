const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

// Set up SQLite database
const db = new sqlite3.Database('database.db');

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS inputs (id INTEGER PRIMARY KEY AUTOINCREMENT, FirstName TEXT, LastName TEXT, Email TEXT)");
});
// Route to handle input saving
app.post('/save-inputs', (req, res) => {
    const { FirstName, LastName, Email } = req.body;
    
    const stmt = db.prepare("INSERT INTO inputs (FirstName, LastName, Email) VALUES (?, ?, ?)");
    stmt.run(FirstName, LastName, Email, function (err) {
        if (err) {
            return res.status(500).json({ message: 'Error saving inputs.' });
        }
        res.json({ message: 'Inputs saved successfully!' });
    });
    stmt.finalize();
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

